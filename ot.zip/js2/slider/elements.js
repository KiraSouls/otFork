const elements = [
    {
        title:'$2.500',
        subtitle:'Promoción estudiante',
        image: './img/estudiante.jpg',
        text: '-Café late <br> -Cinnamon roll'
    },
    {
        title:'$2.500',
        subtitle:'Promoción estudiante',
        image: './img/estudiante2.jpg',
        text: '-Café Americano <br> -Kladdkaka'
    },
    {
        title:'$3.500',
        subtitle:'Promoción Comunidad FIka',
        image: './img/3500.jpg',
        text: '-Café <br> -Sandwich Panini'
    },{
        title:'$5.900',
        subtitle:'Promoción Comunidad FIka',
        image: './img/5900.jpg',
        text: '-Café <br> -Sandwich Panini <br -Jugo <br> -Cinnamon roll'
    },{
        title:'Almuerzo',
        subtitle:'Promoción convenio',
        image: './img/lunchpromo.jpg',
        text: 'aLorem ipsum dolor sit amet consectetur adipisicing elit. Minus, ad atque. Incidunt adipisci corrupti voluptas nemo atque, assumenda nobis necessitatibus earum eaque illum at voluptate expedita veniam voluptatum! Veniam, esse?'
    }
];

export default elements;