<?php @session_start();
$con = new mysqli('localhost', 'root', '', 'scinform_ot_modules');
$con->set_charset('utf8');
