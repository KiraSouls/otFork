<?php
    //sendgrid key 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
  $API_KEY = '39d70fa7da8cf551b0024b0fe048e83d-6d8d428c-73111694';
 ?>

